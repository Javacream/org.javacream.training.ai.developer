# Voraussetzungen

- JDK 17 oder neuer (JDK 21 empfohlen), Maven 3.9+, Ollama installiert.
- Ollama starten: `ollama serve` (nur wenn nicht bereits als Dienst aktiv).
- Chat-Modell: `ollama pull qwen2.5:7b`.
- Standard: `http://localhost:11434`; abweichend über `OLLAMA_BASE_URL`.
- Kein externer API-Key erforderlich. Modellaufrufe benötigen lokal genügend RAM.
- Modellnamen lassen sich über `OLLAMA_CHAT_MODEL` ändern; Eigenschaften des Modells beeinflussen die Ergebnisse.

Für den FactCheckingEvaluator zusätzlich `ollama pull bespoke-minicheck`; Modell wird nur bei dieser Übung gewählt.
