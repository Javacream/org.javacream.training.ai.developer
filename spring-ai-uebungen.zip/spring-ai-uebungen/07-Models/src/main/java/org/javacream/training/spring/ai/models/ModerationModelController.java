package org.javacream.training.spring.ai.models;
import java.util.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.ai.chat.client.ChatClient;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/moderation-model")
@Tag(name = "ModerationModel")
public class ModerationModelController {
 private final ChatClient chatClient;
 
 public ModerationModelController(ChatClient chatClient) { this.chatClient = chatClient;  }
 @PostMapping
 @Operation(summary = "ModerationModel", description = "Provider-Grenze: dieser dedizierte Model-Typ ist mit dem Ollama-Adapter nicht verfügbar")
 public Object execute(@RequestBody String message) {
 throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.NOT_IMPLEMENTED, "ModerationModel: kein dedizierter Spring-AI-Ollama-Adapter. Siehe requirements.md.");
 }
 
}
