# Voraussetzungen

- JDK 17 oder neuer (JDK 21 empfohlen), Maven 3.9+, Ollama installiert.
- Ollama starten: `ollama serve` (nur wenn nicht bereits als Dienst aktiv).
- Chat-Modell: `ollama pull llama3.2`.
- Standard: `http://localhost:11434`; abweichend über `OLLAMA_BASE_URL`.
- Kein externer API-Key erforderlich. Modellaufrufe benötigen lokal genügend RAM.
- Modellnamen lassen sich über `OLLAMA_CHAT_MODEL` ändern; Eigenschaften des Modells beeinflussen die Ergebnisse.

Docker Engine / Docker Desktop mit Compose v2. Cassandra 5 wird über `docker compose up -d --wait` gestartet. Port 9042 muss frei sein. Mindestens 4 GB RAM für Cassandra einplanen. Anschließend `docker compose run --rm cassandra-init`. Daten bleiben in einem Docker-Volume erhalten.
